#include <stdio.h>
// int float
int main()
{
    int a;
    scanf("%d", &a);

return 0;
}
