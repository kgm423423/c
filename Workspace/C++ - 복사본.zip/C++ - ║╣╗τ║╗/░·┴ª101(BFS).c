#include <stdio.h>
#include <vector>

int main()
{

    vector arr[9];

    arr[1].pushback(2,3,8);
    arr[2].pushback(1,7);





    return 0;
}
