#include <stdio.h>

int main()
{
    int n,m;

    scanf("%d %d", &n, &m);

    printf("%d\n",(n+m)/2);
    printf("%d\n",(n-m)/2);

    return 0;
}
