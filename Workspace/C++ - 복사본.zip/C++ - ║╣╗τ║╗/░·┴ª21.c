#include <stdio.h>

int main()
{
    int i,j,n,m,k,x,y;

    scanf("%d %d",&i ,&j);

    int arr[j][i];

    y=i;
    x=j;







    return 0;
}
