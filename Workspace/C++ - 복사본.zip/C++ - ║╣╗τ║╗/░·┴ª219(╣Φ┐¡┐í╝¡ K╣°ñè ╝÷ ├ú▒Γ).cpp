#include <stdio.h>

int main()
{
    int n,k;

    scanf("%d %d", &n, &k);

    printf("%d", n*n);

    int arr[n*n];

    return 0;
}
