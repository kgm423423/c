#include <stdio.h>      //fin
#include <stack>

using namespace std;

char n1 = '\0'
char n2= '\0'

 stack <int> nums;
 stack <char> opts;

int charToInt(char k)
{
    return k - 48;
}

int main()
{
    int num;
    char opt = '\0'



    return 0;
}
