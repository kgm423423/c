#include <stdio.h>

int main()
{
    int i;
    char arr[100];

    scanf("%s",& arr);
    for(i=0;arr[i]!='\0';i++) {}

    printf("%d",i);

    return 0;
}
