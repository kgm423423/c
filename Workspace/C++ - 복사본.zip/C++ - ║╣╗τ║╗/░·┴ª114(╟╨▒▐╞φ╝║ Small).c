#incluce <stdio.h>

int main()
{
    int n,m;




    return 0;
}
