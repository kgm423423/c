#include <stdio.h>

int main()
{
    char a;
    scanf("%c",&a);
    printf("%c",a+1);
    return 0;
}
