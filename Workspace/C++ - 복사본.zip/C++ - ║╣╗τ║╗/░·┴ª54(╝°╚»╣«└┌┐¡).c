#include <stdio.h>

int main()
{
    int i,j;
    _Bool d;
    char s1[20], s2[20], s3[20];

    fgets(s1, sizeof(s1), stdin);
    fgets(s2, sizeof(s2), stdin);
    fgets(s3, sizeof(s3), stdin);



    return 0;
}
